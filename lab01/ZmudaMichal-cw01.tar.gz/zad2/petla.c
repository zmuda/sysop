#include <stdlib.h>

int main(int argc, char* argv[]){
    int k=1;
    long long unsigned res=0;
    while(k){
	res = res+1;
    }
    res=0;
    return res;
}
