#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[]){
    int i=7;
    int k=0;
    int res = i/k;
    return res;
}
