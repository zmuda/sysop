#ifndef _ILOCZYN_H_
#define _ILOCZYN_H_

#include "macierz.h"

macierz_t *iloczyn(macierz_t *m1, macierz_t *m2);

#endif
