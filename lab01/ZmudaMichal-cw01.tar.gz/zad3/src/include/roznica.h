#ifndef _ROZNICA_H_
#define _ROZNICA_H_

#include "macierz.h"

macierz_t *roznica(macierz_t *m1, macierz_t *m2);

#endif
