#ifndef _SUMA_H_
#define _SUMA_H_

#include "macierz.h"

macierz_t *suma(macierz_t *m1, macierz_t *m2);

#endif
