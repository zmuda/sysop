#ifndef _WCZYTAJ_H_
#define _WCZYTAJ_H_

#include "macierz.h"

macierz_t *wczytaj();

#endif
