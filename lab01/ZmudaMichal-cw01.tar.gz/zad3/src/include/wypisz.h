#ifndef _WYPISZ_H_
#define _WYPISZ_H_

#include "macierz.h"

void wypisz(macierz_t *m);

#endif
