
char __plik[512];
